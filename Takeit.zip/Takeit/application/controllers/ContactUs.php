<?php

class ContactUs extends MY_Controller{
	function index(){
		echo "Contact Us on <b>takeitcorporation@gmail.com</b> </br>Thank you...";
	}
}