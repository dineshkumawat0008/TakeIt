<?php

phpinfo();
?>